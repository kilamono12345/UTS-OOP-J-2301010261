 

package com.mycompany.aplikasih;

import java.util.Scanner;

public class Aplikasih {
    // Array untuk menyimpan catatan
    static String[] notes = new String[100]; // Maks 100 catatan
    static int count = 0; // Jumlah catatan saat ini
    static Scanner input = new Scanner(System.in);

    public static void main(String[] args) {
        int choice;
        do {
            showMenu();
            choice = input.nextInt();
            input.nextLine(); // konsumsi newline
            switch (choice) {
                case 1:
                    addNote();
                    break;
                case 2:
                    displayNotes();
                    break;
                case 3:
                    updateNote();
                    break;
                case 4:
                    deleteNote();
                    break;
                case 5:
                    System.out.println("Terima kasih! Keluar dari aplikasi.");
                    break;
                default:
                    System.out.println("Pilihan tidak valid.");
            }
        } while (choice != 5);
    }

    // Menampilkan menu utama
    static void showMenu() {
        System.out.println("\n=== MENU APLIKASI CATATAN ===");
        System.out.println("1. Tambah Catatan");
        System.out.println("2. Tampilkan Semua Catatan");
        System.out.println("3. Ubah Catatan");
        System.out.println("4. Hapus Catatan");
        System.out.println("5. Keluar");
        System.out.print("Pilih menu: ");
    }

    // Tambah catatan
    static void addNote() {
        if (count < notes.length) {
            System.out.print("Masukkan catatan baru: ");
            notes[count] = input.nextLine();
            count++;
            System.out.println("Catatan berhasil ditambahkan.");
        } else {
            System.out.println("Penyimpanan catatan penuh.");
        }
    }

    // Tampilkan semua catatan
    static void displayNotes() {
        System.out.println("\n=== Daftar Catatan ===");
        if (count == 0) {
            System.out.println("Belum ada catatan.");
        } else {
            for (int i = 0; i < count; i++) {
                System.out.println((i + 1) + ". " + notes[i]);
            }
        }
    }

    // Ubah catatan
    static void updateNote() {
        displayNotes();
        if (count > 0) {
            System.out.print("Pilih nomor catatan yang akan diubah: ");
            int index = input.nextInt() - 1;
            input.nextLine(); // konsumsi newline
            if (index >= 0 && index < count) {
                System.out.print("Masukkan catatan baru: ");
                notes[index] = input.nextLine();
                System.out.println("Catatan berhasil diubah.");
            } else {
                System.out.println("Nomor tidak valid.");
            }
        }
    }

    // Hapus catatan
    static void deleteNote() {
        displayNotes();
        if (count > 0) {
            System.out.print("Pilih nomor catatan yang akan dihapus: ");
            int index = input.nextInt() - 1;
            input.nextLine(); // konsumsi newline
            if (index >= 0 && index < count) {
                for (int i = index; i < count - 1; i++) {
                    notes[i] = notes[i + 1];
                }
                notes[count - 1] = null;
                count--;
                System.out.println("Catatan berhasil dihapus.");
            } else {
                System.out.println("Nomor tidak valid.");
            }
        }
    }
}
