
package com.mycompany.aplikasih;

import java.util.Scanner;
public class Array {
    
    

public class Main {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        String[] catatan = new String[100]; // Array untuk menyimpan catatan
        int jumlah = 0; // Menyimpan jumlah catatan

        int pilihan;

        do {
            System.out.println("\n=== MENU CATATAN ===");
            System.out.println("1. Tambah Catatan");
            System.out.println("2. Lihat Catatan");
            System.out.println("3. Keluar");
            System.out.print("Pilih: ");
            pilihan = input.nextInt();
            input.nextLine(); // Konsumsi enter

            switch (pilihan) {
                case 1:
                    if (jumlah < catatan.length) {
                        System.out.print("Masukkan catatan: ");
                        catatan[jumlah] = input.nextLine();
                        jumlah++;
                        System.out.println("Catatan ditambahkan.");
                    } else {
                        System.out.println("Penyimpanan catatan penuh!");
                    }
                    break;
                case 2:
                    System.out.println("\n== Daftar Catatan ==");
                    for (int i = 0; i < jumlah; i++) {
                        System.out.println((i + 1) + ". " + catatan[i]);
                    }
                    break;
                case 3:
                    System.out.println("Keluar dari program.");
                    break;
                default:
                    System.out.println("Pilihan tidak valid.");
            }
        } while (pilihan != 3);
    }
}

    
}
