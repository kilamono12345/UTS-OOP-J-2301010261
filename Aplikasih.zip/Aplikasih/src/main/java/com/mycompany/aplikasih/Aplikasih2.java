
package com.mycompany.aplikasih;

import java.util.Scanner;
public class Aplikasih2 {
    
   
    private String[] notes;  // private karena hanya boleh diakses di dalam kelas Main
    private int count;       // private karena hanya boleh diakses di dalam kelas Main
    private Scanner input;    // private untuk scanner

    // Constructor
    public Aplikasih2() {
        notes = new String[100];  // Array untuk menyimpan catatan
        count = 0;                 // Inisialisasi jumlah catatan
        input = new Scanner(System.in);  // Scanner untuk input user
    }

    // Menampilkan menu aplikasi
    public void showMenu() {
        System.out.println("\n=== MENU APLIKASI CATATAN ===");
        System.out.println("1. Tambah Catatan");
        System.out.println("2. Tampilkan Semua Catatan");
        System.out.println("3. Ubah Catatan");
        System.out.println("4. Hapus Catatan");
        System.out.println("5. Keluar");
        System.out.print("Pilih menu: ");
    }

    // Menambahkan catatan tanpa parameter (mengambil input dari pengguna)
    public void addNote() {
        if (count < notes.length) {
            System.out.print("Masukkan catatan baru: ");
            notes[count] = input.nextLine();
            count++;
            System.out.println("Catatan berhasil ditambahkan.");
        } else {
            System.out.println("Penyimpanan catatan penuh.");
        }
    }

    // Method overloaded: Menambahkan catatan dengan parameter (langsung input String)
    public void addNote(String note) {
        if (count < notes.length) {
            notes[count] = note;
            count++;
            System.out.println("Catatan berhasil ditambahkan: " + note);
        } else {
            System.out.println("Penyimpanan catatan penuh.");
        }
    }

    // Menampilkan semua catatan
    public void displayNotes() {
        System.out.println("\n=== Daftar Catatan ===");
        if (count == 0) {
            System.out.println("Belum ada catatan.");
        } else {
            for (int i = 0; i < count; i++) {
                System.out.println((i + 1) + ". " + notes[i]);
            }
        }
    }

    // Mengubah catatan
    public void updateNote() {
        displayNotes();
        if (count > 0) {
            System.out.print("Pilih nomor catatan yang akan diubah: ");
            int index = input.nextInt() - 1;
            input.nextLine();  // consume the newline character
            if (index >= 0 && index < count) {
                System.out.print("Masukkan catatan baru: ");
                notes[index] = input.nextLine();
                System.out.println("Catatan berhasil diubah.");
            } else {
                System.out.println("Nomor tidak valid.");
            }
        }
    }

    // Menghapus catatan
    public void deleteNote() {
        displayNotes();
        if (count > 0) {
            System.out.print("Pilih nomor catatan yang akan dihapus: ");
            int index = input.nextInt() - 1;
            input.nextLine();  // consume the newline character
            if (index >= 0 && index < count) {
                for (int i = index; i < count - 1; i++) {
                    notes[i] = notes[i + 1];
                }
                notes[count - 1] = null;
                count--;
                System.out.println("Catatan berhasil dihapus.");
            } else {
                System.out.println("Nomor tidak valid.");
            }
        }
    }
    
}
